package labelnet.cn.ledou.util;

/**
 * Created by yuan on 15-9-23.
 *
 *
 * 定义一些 常量
 */
public class FinalUtil {

    /**
     * Sharedference 名字
     */
    public static final String SHARED_NAME="ledou";

    /**
     * 欢迎界面第一次运行 key值
     */
    public static final String WELCOME_ONCE="welcome";

}
