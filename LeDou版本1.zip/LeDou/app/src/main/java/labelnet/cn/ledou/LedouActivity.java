package labelnet.cn.ledou;

import android.app.Activity;
import android.os.Bundle;

public class LedouActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ledou);
    }




}
